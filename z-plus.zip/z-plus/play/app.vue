<template>
    <ZIcon color="red" :size="30" class="z-icon-loading">hello zf</ZIcon>
</template>