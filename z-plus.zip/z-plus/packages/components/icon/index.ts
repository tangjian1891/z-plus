import { withInstall } from "@z-plus/utils/with-intall";
import Icon from "./src/icon.vue";
const ZIcon = withInstall(Icon);

export {
    ZIcon
}
export default ZIcon;
